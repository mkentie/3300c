/*
  Copyright (C) 2001 Bertrik Sikken (bertrik@zonnet.nl)

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  $Id: niash_libusb.c,v 1.2 2004/10/10 20:37:56 ullsig Exp $
*/

/*
    Provides a simple interface to read and write data from the scanner,
    without any knowledge whether it's a parallel or USB scanner
*/


#include "niash_libusb.h"
#include <string.h>
#include <stdio.h>		/* printf */
#include <usb.h>		/* libusb include file */


/************************************************************************
  USB transfer routines implemented with libusb calls
************************************************************************/

#define LIBUSB_TIMEOUT  20000L
#define NIASH_BULK_IN  0x81
#define NIASH_BULK_OUT 0x02

#define LIBUSB_FORMAT   "libusb(%s,%s)"

void
NiashLibUsbInit (TFnReportDevice * pfnReportDevice)
{
  struct usb_bus *pbus;
  struct usb_device *pdev;
  char szDeviceName[32];
  int fFoundDevice = 0;
  TScannerModel *pModel;

  usb_init ();
  usb_find_busses ();
  usb_find_devices ();
  for (pbus = usb_busses; pbus; pbus = pbus->next)
    {
      for (pdev = pbus->devices; pdev; pdev = pdev->next)
	{
/*      DBG(DBG_MSG, "Bus %s Dev %s : 0x%04X-0x%04X\n", pbus->dirname, pdev->filename,
              pdev->descriptor.idVendor, pdev->descriptor.idProduct);
*/
	  if (MatchUsbDevice (pdev->descriptor.idVendor,
			      pdev->descriptor.idProduct, &pModel))
	    {

              fFoundDevice = 1;
	      sprintf (szDeviceName, LIBUSB_FORMAT, pbus->dirname,
		       pdev->filename);
	      pfnReportDevice (pModel, szDeviceName);
	    }
	}
    }
  if ( !fFoundDevice )
  {
       DBG (DBG_ERR, "No LibUSB niash-scanner devices found\n");
  }
}


int
NiashLibUsbOpen (char const *pszName, EScannerModel * peModel)
{
  struct usb_bus *pbus;
  struct usb_device *pdev;
  usb_dev_handle *devLibUsb;
  char szDeviceName[32];
  TScannerModel *pModel;

  usb_find_busses ();
  usb_find_devices ();
  for (pbus = usb_busses; pbus; pbus = pbus->next)
    {
      for (pdev = pbus->devices; pdev; pdev = pdev->next)
	{

	  sprintf (szDeviceName, LIBUSB_FORMAT, pbus->dirname,
		   pdev->filename);

	  if (strcmp (pszName, szDeviceName) == 0)
	    {
	      /* try to open */
	      devLibUsb = usb_open (pdev);
	      if (usb_claim_interface (devLibUsb, 0) < 0)
		{
		  DBG (DBG_ERR, "ERROR: usb_claim_interface failed\n");
		  usb_close (devLibUsb);
		  break;
		}
	      if (MatchUsbDevice (pdev->descriptor.idVendor,
				  pdev->descriptor.idProduct, &pModel))
		{
		  *peModel = pModel->eModel;
		}
	      return (int) devLibUsb;
	    }
	}
    }
  return -1;
}


void
NiashLibUsbExit (int iHandle)
{
  usb_dev_handle *devLibUsb;

  if (iHandle < 0)
    {
      DBG (DBG_ERR, "ERROR: LibUsbExit - nothing to close\n");
      return;
    }

  devLibUsb = (usb_dev_handle *) iHandle;

  if (usb_release_interface (devLibUsb, 0) != 0)
    {
      DBG (DBG_ERR, "ERROR: LibUsbExit - could not release interface (%d)\n",
	   (int) devLibUsb);
    }
  usb_close (devLibUsb);
}


static void
_LibUsbReadControl (int iHandle, SANE_Byte bValue, SANE_Byte * pabData, int iSize)
{
  int iRequest;
  usb_dev_handle *devLibUsb;

  if (iHandle < 0)
    {
      return;
    }

  devLibUsb = (usb_dev_handle *) iHandle;

  iRequest = (iSize > 1) ? 0x04 : 0x0C;

  usb_control_msg (devLibUsb, 0xC0, iRequest, bValue, 0, (char *) pabData,
		   iSize, LIBUSB_TIMEOUT);
}


static void
_LibUsbWriteControl (int iHandle, SANE_Byte bValue, SANE_Byte * pabData, int iSize)
{
  int iRequest;
  usb_dev_handle *devLibUsb;

  if (iHandle < 0)
    {
      return;
    }

  devLibUsb = (usb_dev_handle *) iHandle;

  iRequest = (iSize > 1) ? 0x04 : 0x0C;

  usb_control_msg (devLibUsb, 0x40, iRequest, bValue, 0, (char *) pabData,
		   iSize, LIBUSB_TIMEOUT);
}

void
NiashLibUsbWriteReg (int iHandle, SANE_Byte bReg, SANE_Byte bData)
{
  _LibUsbWriteControl (iHandle, bReg, &bData, 1);
}


void
NiashLibUsbReadReg (int iHandle, SANE_Byte bReg, SANE_Byte * pbData)
{
  _LibUsbReadControl (iHandle, bReg, pbData, 1);
}


void
NiashLibUsbWriteBulk (int iHandle, SANE_Byte * pabData, int iSize)
{
  SANE_Byte abSetup[8] = { 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
  int iWritten;
  usb_dev_handle *devLibUsb;

  if (iHandle < 0)
    {
      return;
    }

  devLibUsb = (usb_dev_handle *) iHandle;

  abSetup[4] = (iSize) & 0xFF;
  abSetup[5] = (iSize >> 8) & 0xFF;
  _LibUsbWriteControl (iHandle, USB_SETUP, abSetup, 8);
  iWritten = usb_bulk_write (devLibUsb, NIASH_BULK_OUT, (char *) pabData,
			     iSize, LIBUSB_TIMEOUT);
  if (iWritten != iSize)
    {
/* usb_bulk_write of libusb 0.1.4 returns # of bytes written instead of 0 */
      DBG (DBG_ERR, "ERROR: usb_bulk_write failed (wrote %d, should be %d)\n",
	   iWritten, iSize);
    }
}


void
NiashLibUsbReadBulk (int iHandle, SANE_Byte * pabData, int iSize)
{
  SANE_Byte abSetup[8] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
  int iRead;
  usb_dev_handle *devLibUsb;

  if (iHandle < 0)
    {
      return;
    }

  devLibUsb = (usb_dev_handle *) iHandle;

  abSetup[4] = (iSize) & 0xFF;
  abSetup[5] = (iSize >> 8) & 0xFF;
  _LibUsbWriteControl (iHandle, USB_SETUP, abSetup, 8);
  iRead = usb_bulk_read (devLibUsb, NIASH_BULK_IN, (char *) pabData, iSize,
			 LIBUSB_TIMEOUT);
  if (iRead != iSize)
    {
      DBG (DBG_ERR, "ERROR: usb_bulk_read failed (read %d, should be %d)\n",
	   iRead, iSize);
    }
}
