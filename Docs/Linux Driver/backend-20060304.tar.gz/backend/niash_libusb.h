/*
  Copyright (C) 2001 Bertrik Sikken (bertrik@zonnet.nl)

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

  $Id: niash_libusb.h,v 1.2 2004/10/10 20:37:56 ullsig Exp $
*/

/*
    Core NIASH LibUSB commnication functions.
*/
#ifndef _NIASH_LIBUSB_H_
#define _NIASH_LIBUSB_H_

#include "niash_xfer.h"

void
NiashLibUsbInit (TFnReportDevice * pfnReportDevice);

int
NiashLibUsbOpen (char const *pszName, EScannerModel * peModel);

void
NiashLibUsbExit (int iHandle);

void
NiashLibUsbWriteReg (int iHandle, SANE_Byte bReg, SANE_Byte bData);


void
NiashLibUsbReadReg (int iHandle, SANE_Byte bReg, SANE_Byte * pbData);

void
NiashLibUsbWriteBulk (int iHandle, SANE_Byte * pabData, int iSize);

void
NiashLibUsbReadBulk (int iHandle, SANE_Byte * pabData, int iSize);
#endif
